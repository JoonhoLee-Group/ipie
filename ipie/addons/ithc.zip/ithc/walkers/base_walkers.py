# Copyright 2022 The ipie Developers. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Authors: Fionn Malone <fmalone@google.com>
#          Joonho Lee
#          Ankit Mahajan <ankitmahajan76@gmail.com>
#          Jinghong Zhang <jinghongzhang@fas.harvard.edu>
#

import cmath
import os
from abc import ABCMeta, abstractmethod

import h5py
import numpy

from ipie.utils.backend import arraylib as xp
from ipie.utils.backend import to_host
from ipie.utils.io import format_fixed_width_floats


class WalkerAccumulator:
    """Small class to handle passing around walker state."""

    def __init__(self, names, nsteps):
        self.names = names
        self.size = len(names)
        self.buffer = numpy.zeros((self.size,), dtype=numpy.complex128)
        self._data_index = {k: i for i, k in enumerate(self.names)}
        self.nsteps_per_block = nsteps
        self._eshift = 0.0

    def update(self, walkers):
        self.buffer += numpy.array(
            [
                to_host(xp.sum(walkers.weight)),
                to_host(xp.sum(walkers.unscaled_weight)),
                to_host(xp.sum(walkers.weight * walkers.hybrid_energy)),
            ]
        )

    def zero(self):
        self.buffer.fill(0.0j)

    def get_index(self, name):
        index = self._data_index.get(name, None)
        if index is None:
            raise RuntimeError(f"Unknown walker property {name}")
        return index

    @property
    def eshift(self):
        return self._eshift.real

    @eshift.setter
    def eshift(self, value):
        self._eshift = value

    def post_reduce_hook(self, vals, block):
        assert len(vals) == len(self.names)
        if block == 0:
            factor = 1
        else:
            factor = self.nsteps_per_block
        nume = self.get_index("HybridEnergy")
        deno = self.get_index("Weight")
        vals[nume] = vals[nume] / vals[deno]
        vals[deno] = vals[deno] / factor
        ix = self.get_index("WeightFactor")
        vals[ix] = vals[ix] / factor

    def to_text(self, vals):
        return format_fixed_width_floats(vals.real)


class BaseWalkers(metaclass=ABCMeta):
    """Container for groups of walkers which make up a wavefunction.

    Parameters
    ----------
    system : object
        System object.
    nwalkers : int
        Number of walkers to initialise.
    """

    def __init__(
        self,
        nwalkers,
        write_filepath=None,
        write_restart=False,
        write_freq=None,
        write_time=None,
        verbose=False,
    ):
        self.nwalkers = nwalkers

        if verbose:
            print("# Setting up BaseWalkers.")
            print(f"# nwalkers = {self.nwalkers}")

        self.weight = xp.array(
            [1.0 for iw in range(self.nwalkers)]  # TODO: allow for arbitrary initial weights
        )
        self.unscaled_weight = self.weight.copy()
        self.phase = xp.array([1.0 + 0.0j for iw in range(self.nwalkers)])

        self.ovlp = xp.array([1.0 for iw in range(self.nwalkers)])
        self.sgn_ovlp = xp.array([1.0 for iw in range(self.nwalkers)])
        self.log_ovlp = xp.array([0.0 for iw in range(self.nwalkers)])

        # in case we use local energy approximation to the propagation
        self.eloc = xp.array([0.0 for iw in range(self.nwalkers)])

        self.hybrid_energy = xp.array([0.0 for iw in range(self.nwalkers)])
        self.detR = xp.array([1.0 for iw in range(self.nwalkers)])
        self.detR_shift = xp.array([0.0 for iw in range(self.nwalkers)])
        self.log_detR = xp.array([0.0 for iw in range(self.nwalkers)])
        self.log_shift = xp.array([0.0 for iw in range(self.nwalkers)])
        self.log_detR_shift = xp.array([0.0 for iw in range(self.nwalkers)])

        self.buff_names = [
            "weight",
            "unscaled_weight",
            "phase",
            "hybrid_energy",
            "ovlp",
            "sgn_ovlp",
            "log_ovlp",
        ]
        self.buff_size = None
        self.walker_buffer = None
        self.write_filepath = write_filepath
        self.read_filepath = write_filepath
        self.write_restart = write_restart
        self.write_freq = write_freq
        self.write_time = write_time

        if verbose:
            print("# Finish setting up walkers.handler.Walkers.")

    def set_buff_size_single_walker(self):
        names = []
        size = 0
        for k, v in self.__dict__.items():
            if not (k in self.buff_names):
                continue
            if isinstance(v, (xp.ndarray, numpy.ndarray)):
                names.append(k)
                size += v.size
            elif isinstance(v, (int, float, complex)):
                names.append(k)
                size += 1
            elif isinstance(v, list):
                names.append(k)
                for l in v:
                    if isinstance(l, (xp.ndarray)):
                        size += l.size
                    elif isinstance(l, (int, float, complex)):
                        size += 1
        return size

    def orthogonalise(self, free_projection=False):
        """Orthogonalise all walkers.

        Parameters
        ----------
        free_projection : bool
            True if doing free projection.
        """
        detR = self.reortho()
        if free_projection:
            magn, dtheta = cmath.polar(self.detR)
            self.weight *= magn
            self.phase *= cmath.exp(1j * dtheta)
        return detR

    def get_write_buffer(self):
        buff = numpy.concatenate(
            [
                [self.weight],
                [self.phase],
                [self.ovlp],
                self.phi.ravel(),
            ]
        )
        return buff

    def set_walkers_from_buffer(self, buff):
        self.weight = buff[0 : self.nwalkers]
        self.phase = buff[self.nwalkers : self.nwalkers * 2]
        self.ovlp = buff[self.nwalkers * 2 : self.nwalkers * 3]
        self.phi = buff[self.nwalkers * 3 :].reshape(self.phi.shape)

    def write_walkers_batch(self, comm):
        write_dir = self.write_filepath if self.write_filepath is not None else ""
        write_file = os.path.join(write_dir, f"walkers_{comm.rank}.h5")
        with h5py.File(write_file, "a") as fh5:
            num_slices = len(fh5.keys()) // 3
            phia = self.phia
            phib = self.phib
            weight = self.weight
            hybrid_energy = self.hybrid_energy
            if isinstance(phia, numpy.ndarray):
                fh5[f"walker_timeslice_{num_slices}"] = numpy.concatenate([phia, phib], axis=-1)
                fh5[f"walker_weight_{num_slices}"] = weight
                fh5[f"walker_hybrid_energy_{num_slices}"] = hybrid_energy
            else:
                fh5[f"walker_timeslice_{num_slices}"] = numpy.concatenate(
                    [xp.asnumpy(phia), xp.asnumpy(phib)], axis=-1
                )
                fh5[f"walker_weight_{num_slices}"] = xp.asnumpy(weight)
                fh5[f"walker_hybrid_energy_{num_slices}"] = xp.asnumpy(hybrid_energy)

    def read_walkers_batch(self, trial, comm):
        read_dir = self.read_filepath if self.read_filepath is not None else ""
        read_file = os.path.join(read_dir, f"walkers_{comm.rank}.h5")
        with h5py.File(read_file, "r") as fh5:
            try:
                num_slices = len(fh5.keys()) // 3 - 1
                timeslice_data = numpy.asarray(fh5[f"walker_timeslice_{num_slices}"][()])
                if timeslice_data.ndim == 3:
                    nup = getattr(self, "nup", None)
                    ndown = getattr(self, "ndown", None)
                    assert (
                        nup is not None and ndown is not None
                    ), "Need nup and ndown to read 2D walker data."
                    assert (
                        timeslice_data.shape[-1] == nup + ndown
                    ), "nup + ndown does not match walker data shape."
                    phia = timeslice_data[:, :, :nup]
                    phib = timeslice_data[:, :, nup : nup + ndown]
                else:
                    phia = timeslice_data[0]
                    phib = timeslice_data[1]
                self.phia = xp.array(phia)
                self.phib = xp.array(phib)
                weight = fh5[f"walker_weight_{num_slices}"][:]
                hybrid_energy = fh5[f"walker_hybrid_energy_{num_slices}"][:]
                self.weight = xp.array(weight)
                self.hybrid_energy = xp.array(hybrid_energy)
                self.ovlp = trial.calc_greens_function(self)

            except KeyError:
                print(f" # Could not read walker data from: {read_file}")

    @abstractmethod
    def reortho(self):
        pass

    @abstractmethod
    def reortho_batched(self):  # gpu version
        pass
